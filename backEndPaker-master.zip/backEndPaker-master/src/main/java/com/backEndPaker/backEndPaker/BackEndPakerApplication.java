package com.backEndPaker.backEndPaker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndPakerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndPakerApplication.class, args);
	}

}
