package com.backEndPaker.backEndPaker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndPakerApplicationTests {

	@Test
	void contextLoads() {
	}

}
